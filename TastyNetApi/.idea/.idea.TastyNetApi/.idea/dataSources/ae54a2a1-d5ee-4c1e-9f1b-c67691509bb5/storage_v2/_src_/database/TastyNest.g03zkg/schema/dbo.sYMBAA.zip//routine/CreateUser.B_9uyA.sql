CREATE PROCEDURE [dbo].[CreateUser]
	@Identificacion varchar(20),
	@Nombre			varchar(255),
	@Correo			varchar(80),
	@Contrasenna	varchar(255)
AS
BEGIN

	DECLARE @EstadoActivo BIT = 1,
			@RolUsuario INT,
			@UsaClaveTemp BIT = 0

	SELECT	@RolUsuario = Id
	FROM	dbo.Roles
	WHERE	RolName = 'Clientes'

	IF NOT EXISTS(SELECT 1 FROM dbo.Users 
			      WHERE IdentificationNumber = @Identificacion
					OR	Email = @Correo)
	BEGIN
		INSERT INTO dbo.Users (IdentificationNumber,Name,Email,Password,Active,RoleId,UseTempPassword,Validity)
		VALUES (@Identificacion,@Nombre,@Correo,@Contrasenna,@EstadoActivo,@RolUsuario,@UsaClaveTemp,GETDATE())
	END

END
go

